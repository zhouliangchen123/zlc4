(function() {
  'use strict';

  const STORAGE_KEY = 'nebulachat_history_v1';
  const THEME_KEY = 'nebulachat_theme';

  // ================== Clock ==================
  function padZero(n) { return n < 10 ? '0' + n : '' + n; }

  function formatTime(d) {
    return padZero(d.getHours()) + ':' + padZero(d.getMinutes()) + ':' + padZero(d.getSeconds());
  }

  function formatDateCN(d) {
    const weekdays = ['周日', '周一', '周二', '周三', '周四', '周五', '周六'];
    return d.getFullYear() + '年' + padZero(d.getMonth() + 1) + '月' + padZero(d.getDate()) + '日 ' + weekdays[d.getDay()];
  }

  function formatShortTime(d) {
    return padZero(d.getHours()) + ':' + padZero(d.getMinutes());
  }

  function updateClocks() {
    const now = new Date();
    const time = formatTime(now);
    const date = formatDateCN(now);

    const ids = ['sidebarClock', 'topClock', 'aboutClock'];
    ids.forEach(id => {
      const el = document.getElementById(id);
      if (el) el.textContent = time;
    });

    const dateIds = {
      'sidebarDate': date,
      'topDate': date.slice(0, 10) + ' ' + date.slice(-2),
      'aboutDate': date
    };
    Object.keys(dateIds).forEach(id => {
      const el = document.getElementById(id);
      if (el) el.textContent = dateIds[id];
    });
  }

  // ================== Theme ==================
  function initTheme() {
    const saved = localStorage.getItem(THEME_KEY);
    if (saved) {
      document.documentElement.setAttribute('data-theme', saved);
    }

    const toggleBtn = document.getElementById('themeToggle');
    if (toggleBtn) {
      toggleBtn.addEventListener('click', () => {
        const current = document.documentElement.getAttribute('data-theme');
        const next = current === 'light' ? 'dark' : 'light';
        document.documentElement.setAttribute('data-theme', next);
        localStorage.setItem(THEME_KEY, next);
        showToast(next === 'light' ? '已切换到浅色主题' : '已切换到深色主题');
      });
    }
  }

  // ================== Navigation ==================
  function initNav() {
    const navItems = document.querySelectorAll('.nav-item');
    const views = document.querySelectorAll('.view');
    const viewTitle = document.getElementById('viewTitle');
    const viewSubtitle = document.getElementById('viewSubtitle');

    const titles = {
      chat: ['智能对话', '与 AI 助手交流你的想法'],
      about: ['关于', '了解 NebulaChat 与使用方法']
    };

    navItems.forEach(item => {
      item.addEventListener('click', () => {
        const target = item.dataset.view;
        navItems.forEach(n => n.classList.remove('active'));
        item.classList.add('active');
        views.forEach(v => v.classList.remove('active'));
        const viewEl = document.getElementById('view' + target.charAt(0).toUpperCase() + target.slice(1));
        if (viewEl) viewEl.classList.add('active');
        if (titles[target] && viewTitle) {
          viewTitle.textContent = titles[target][0];
          if (viewSubtitle) viewSubtitle.textContent = titles[target][1];
        }
      });
    });
  }

  // ================== Chat ==================
  let messages = [];
  let isLoading = false;

  function escapeHTML(str) {
    return String(str)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;');
  }

  function simpleMarkdown(text) {
    let html = escapeHTML(text);
    // inline code
    html = html.replace(/`([^`\n]+)`/g, '<code>$1</code>');
    // bold
    html = html.replace(/\*\*([^*]+)\*\*/g, '<strong>$1</strong>');
    // code block
    html = html.replace(/```(?:[a-zA-Z0-9]*)\n?([\s\S]*?)```/g, (_, c) => {
      return '<pre><code>' + c.replace(/<code>|<\/code>/g, '') + '</code></pre>';
    });
    // preserve line breaks
    html = html.replace(/\n/g, '<br>');
    return html;
  }

  function renderMessage(msg, animate) {
    const container = document.getElementById('chatMessages');
    if (!container) return;

    const wrap = document.createElement('div');
    wrap.className = 'message ' + (msg.role === 'user' ? 'user' : 'ai');
    if (!animate) wrap.style.animation = 'none';

    const avatar = document.createElement('div');
    avatar.className = 'message-avatar';
    avatar.textContent = msg.role === 'user' ? '👤' : '🤖';

    const body = document.createElement('div');
    body.className = 'message-body';

    const bubble = document.createElement('div');
    bubble.className = 'message-bubble';
    bubble.innerHTML = simpleMarkdown(msg.content);

    const time = document.createElement('div');
    time.className = 'message-time';
    time.textContent = msg.time || '';

    body.appendChild(bubble);
    body.appendChild(time);
    wrap.appendChild(avatar);
    wrap.appendChild(body);
    container.appendChild(wrap);

    container.scrollTop = container.scrollHeight;
    return { wrap, bubble };
  }

  function showTyping() {
    const container = document.getElementById('chatMessages');
    if (!container) return null;

    const wrap = document.createElement('div');
    wrap.className = 'message ai';
    wrap.id = 'typingIndicator';

    const avatar = document.createElement('div');
    avatar.className = 'message-avatar';
    avatar.textContent = '🤖';

    const body = document.createElement('div');
    body.className = 'message-body';

    const bubble = document.createElement('div');
    bubble.className = 'message-bubble';
    bubble.innerHTML = '<div class="typing"><span></span><span></span><span></span></div>';

    body.appendChild(bubble);
    wrap.appendChild(avatar);
    wrap.appendChild(body);
    container.appendChild(wrap);
    container.scrollTop = container.scrollHeight;
    return wrap;
  }

  function removeTyping() {
    const el = document.getElementById('typingIndicator');
    if (el) el.remove();
  }

  function renderEmptyState() {
    const container = document.getElementById('chatMessages');
    if (!container) return;
    container.innerHTML = `
      <div class="empty-state">
        <div class="empty-state-ico">🌌</div>
        <h3>开启你的智能对话</h3>
        <p>在下方输入框中输入你的问题，或点击快速建议开始对话。对话内容会保存在本地浏览器中。</p>
      </div>
    `;
  }

  function loadHistory() {
    try {
      const data = localStorage.getItem(STORAGE_KEY);
      if (data) {
        messages = JSON.parse(data) || [];
      }
    } catch (e) { messages = []; }

    const container = document.getElementById('chatMessages');
    if (container) container.innerHTML = '';

    if (messages.length === 0) {
      renderEmptyState();
      return;
    }
    messages.forEach(m => renderMessage(m, false));
  }

  function saveHistory() {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(messages));
    } catch (e) { /* ignore */ }
  }

  async function sendMessage(content) {
    content = (content || '').trim();
    if (!content || isLoading) return;

    // Remove empty state if present
    const container = document.getElementById('chatMessages');
    const emptyState = container && container.querySelector('.empty-state');
    if (emptyState && container) container.innerHTML = '';

    const userMsg = {
      role: 'user',
      content: content,
      time: formatShortTime(new Date())
    };
    messages.push(userMsg);
    renderMessage(userMsg, true);
    saveHistory();

    isLoading = true;
    const sendBtn = document.getElementById('sendBtn');
    if (sendBtn) sendBtn.disabled = true;

    const typingEl = showTyping();

    try {
      // 最近 20 条消息作为上下文
      const context = messages.slice(-20).map(m => ({ role: m.role, content: m.content }));
      const reply = await QwenAPI.chat(context);

      removeTyping();

      const aiMsg = {
        role: 'assistant',
        content: reply,
        time: formatShortTime(new Date())
      };
      messages.push(aiMsg);
      renderMessage(aiMsg, true);
      saveHistory();
    } catch (err) {
      removeTyping();
      const errMsg = {
        role: 'assistant',
        content: '⚠️ 抱歉，请求出现问题：' + (err.message || '未知错误') + '\n\n请检查网络连接，或稍后重试。',
        time: formatShortTime(new Date())
      };
      messages.push(errMsg);
      renderMessage(errMsg, true);
      showToast('请求失败：' + (err.message || '未知错误'), true);
    } finally {
      isLoading = false;
      if (sendBtn) sendBtn.disabled = false;
      const input = document.getElementById('chatInput');
      if (input) input.focus();
    }
  }

  function clearChat() {
    if (isLoading) return;
    if (!confirm('确定要清空所有对话记录吗？此操作不可撤销。')) return;
    messages = [];
    saveHistory();
    renderEmptyState();
    showToast('对话已清空');
  }

  function initChat() {
    loadHistory();

    const input = document.getElementById('chatInput');
    const sendBtn = document.getElementById('sendBtn');
    const clearBtn = document.getElementById('clearBtn');

    if (input) {
      input.addEventListener('input', () => {
        input.style.height = 'auto';
        input.style.height = Math.min(input.scrollHeight, 200) + 'px';
      });
      input.addEventListener('keydown', (e) => {
        if (e.key === 'Enter' && !e.shiftKey) {
          e.preventDefault();
          sendMessage(input.value);
          input.value = '';
          input.style.height = 'auto';
        }
      });
    }

    if (sendBtn) {
      sendBtn.addEventListener('click', () => {
        if (!input) return;
        sendMessage(input.value);
        input.value = '';
        input.style.height = 'auto';
      });
    }

    if (clearBtn) {
      clearBtn.addEventListener('click', clearChat);
    }

    document.querySelectorAll('.suggestion-chip').forEach(btn => {
      btn.addEventListener('click', () => {
        const text = btn.dataset.suggestion;
        if (text && input) {
          input.value = text;
          sendMessage(text);
          input.value = '';
          input.style.height = 'auto';
        }
      });
    });
  }

  // ================== Toast ==================
  let toastTimer = null;
  function showToast(message, isError) {
    const toast = document.getElementById('toast');
    if (!toast) return;
    toast.textContent = message;
    toast.classList.toggle('error', !!isError);
    toast.classList.add('show');
    if (toastTimer) clearTimeout(toastTimer);
    toastTimer = setTimeout(() => toast.classList.remove('show'), 2800);
  }

  // ================== Init ==================
  function init() {
    updateClocks();
    setInterval(updateClocks, 1000);
    initTheme();
    initNav();
    initChat();
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
