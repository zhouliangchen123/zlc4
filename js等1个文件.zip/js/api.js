const QwenAPI = {
  async chat(messages) {
    if (!AppConfig.qwenApiKey || AppConfig.qwenApiKey.includes('YOUR_')) {
      throw new Error('API Key 未配置，请在 js/config.js 中设置');
    }

    const requestMessages = [
      { role: 'system', content: AppConfig.systemPrompt },
      ...messages.map(m => ({ role: m.role, content: m.content }))
    ];

    const response = await fetch(AppConfig.qwenApiUrl, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${AppConfig.qwenApiKey}`
      },
      body: JSON.stringify({
        model: AppConfig.qwenModel,
        messages: requestMessages,
        temperature: 0.75,
        top_p: 0.9,
        max_tokens: 2048
      })
    });

    if (!response.ok) {
      let errorMsg = `请求失败 (HTTP ${response.status})`;
      try {
        const errData = await response.json();
        if (errData && errData.error && errData.error.message) {
          errorMsg += ': ' + errData.error.message;
        } else if (errData && errData.message) {
          errorMsg += ': ' + errData.message;
        }
      } catch (_) { }
      throw new Error(errorMsg);
    }

    const data = await response.json();
    if (data && data.choices && data.choices[0] && data.choices[0].message) {
      return data.choices[0].message.content;
    }
    throw new Error('API 返回数据格式异常');
  }
};
